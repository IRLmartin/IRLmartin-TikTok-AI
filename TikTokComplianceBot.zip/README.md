# TikTok Compliance Bot
This bot helps you check TikTok Shop violations.
